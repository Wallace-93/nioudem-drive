
export default function Button({children}:{children:React.ReactNode}){
  return (
    <button className="w-full rounded-2xl bg-[#174E4F] py-4 text-white font-semibold active:scale-[.98] transition">
      {children}
    </button>
  )
}
