
import Button from '../../../../components/Button'

export default function MissionOne(){
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-between bg-[#FAF7F2] p-6">
      <section className="space-y-5">
        <span className="inline-block rounded-full bg-white px-3 py-1 text-sm">
          Déclic #1 · 6 min
        </span>

        <h1 className="text-4xl font-bold leading-tight">
          Pourquoi les petites décisions changent une vie entière.
        </h1>

        <p className="text-lg text-neutral-600">
          Les grandes transformations commencent rarement par de grands événements.
          Elles commencent par une décision répétée.
        </p>

        <div className="aspect-video rounded-3xl bg-neutral-900 text-white grid place-items-center">
          VIDEO_PLACEHOLDER
        </div>

        <div className="rounded-3xl bg-white p-5">
          <h2 className="font-semibold text-xl mb-2">Ta Petite Action</h2>
          <p>Ouvre ton application bancaire et regarde simplement ton solde. Ne juge rien. Observe seulement.</p>
        </div>
      </section>

      <section className="space-y-3">
        <Button>J'ai réalisé cette action</Button>
      </section>
    </main>
  )
}
